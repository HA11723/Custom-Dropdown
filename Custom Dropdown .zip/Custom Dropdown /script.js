// Wait for the DOM content to be fully loaded before running the script
document.addEventListener('DOMContentLoaded', function() {
    const dropdownButton = document.getElementById('dropdownButton');  // The button that triggers the dropdown
    const dropdownMenu = document.getElementById('dropdownMenu');  // The menu containing the items
    const dropdownItems = document.querySelectorAll('.dropdown-item');  // All the menu items
  
    // Set initial state to placeholder text
    dropdownButton.classList.add('placeholder');
    dropdownButton.textContent = "Select an Item";  // Default placeholder text
  
    // Add a click event listener to the dropdown button
    dropdownButton.addEventListener('click', function() {
      // Toggle the visibility of the dropdown menu
      dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
    });
  
    // Loop through each dropdown item and add a click event listener
    dropdownItems.forEach(item => {
      item.addEventListener('click', function() {
        // Set the text of the dropdown button to the selected item's text
        dropdownButton.textContent = item.textContent;
        dropdownButton.classList.remove('placeholder');  // Remove placeholder styling
        dropdownMenu.style.display = 'none';  // Close the dropdown menu
  
        // Remove the 'selected' class from all items
        dropdownItems.forEach(i => i.classList.remove('selected'));
        // Add the 'selected' class to the clicked item (to highlight it)
        item.classList.add('selected');
      });
    });
  
    // Close the dropdown if a click is made outside of the dropdown button or menu
    window.addEventListener('click', function(event) {
      if (!dropdownButton.contains(event.target) && !dropdownMenu.contains(event.target)) {
        dropdownMenu.style.display = 'none';  // Close dropdown if clicked outside
      }
    });
  });
  